# 🛠️ 旅行助手 - 故障排除指南

## 连接问题解决方案

### 1. "Failed to fetch" 错误

这个错误通常表示前端无法连接到Dify后端服务。请按照以下步骤排查：

#### 🔍 检查Dify服务状态
```bash
# 检查Dify服务是否正在运行
curl http://localhost:5001/health

# 如果返回404，尝试检查端口
netstat -ano | findstr :5001
```

#### 🔧 常见解决方案

1. **确认Dify服务正在运行**
   - 打开终端，运行 `docker ps` 查看容器状态
   - 确保Dify相关的容器都在运行

2. **检查API地址配置**
   - 在 `script.js` 文件中，确认 `DIFY_API_URL` 设置正确
   - 默认应该是：`http://localhost:5001/v1`

3. **验证API密钥**
   - 登录Dify控制台
   - 进入 "设置" → "API密钥"
   - 确认使用的密钥有效且未过期

4. **检查防火墙设置**
   - 确保端口5001未被防火墙阻止
   - 临时关闭防火墙测试：`netsh advfirewall set allprofiles state off`

5. **浏览器控制台检查**
   - 按F12打开开发者工具
   - 查看Console标签页的详细错误信息
   - 检查Network标签页的请求状态

### 2. API配置检查清单

#### ✅ 必须配置的项目

1. **API地址** (`DIFY_API_URL`)
   ```javascript
   // 本地开发环境
   const DIFY_API_URL = 'http://localhost:5001/v1';
   
   // 远程服务器
   const DIFY_API_URL = 'http://your-server-ip:5001/v1';
   ```

2. **API密钥** (`DIFY_API_KEY`)
   ```javascript
   // 从Dify控制台获取
   const DIFY_API_KEY = 'app-your-actual-api-key';
   ```

### 3. 快速测试方法

#### 🧪 使用测试按钮
1. 打开旅行助手网页
2. 点击 "测试连接" 按钮
3. 查看弹出的测试结果信息

#### 🧪 手动API测试
```bash
# 测试API连接
curl -X POST http://localhost:5001/v1 \
  -H "Authorization: Bearer your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "inputs": {
      "destination": "北京",
      "days": 3,
      "budget_style": "经济"
    },
    "response_mode": "blocking",
    "user": "test-user"
  }'
```

### 4. 工作流配置检查

#### 📋 确保工作流包含以下输入参数：
- `destination` (字符串) - 目的地
- `days` (数字) - 旅行天数
- `budget_style` (字符串) - 预算风格
- `travel_date` (字符串) - 出发日期
- `total_budget` (数字) - 总预算
- `group_types` (数组) - 人群类型
- `preferences` (数组) - 特殊偏好
- `must_visit` (数组) - 必去景点
- `avoid_items` (数组) - 避开项目

#### 📋 确保工作流输出格式：
工作流应该返回一个包含 `text` 字段的对象，例如：
```json
{
  "data": {
    "outputs": {
      "text": "您的旅行计划内容..."
    }
  }
}
```

### 5. 调试模式

在 `script.js` 文件中，设置 `DEBUG_MODE = true` 可以查看详细的调试信息：

```javascript
const DEBUG_MODE = true; // 开启调试模式
```

这将显示：
- API请求详细信息
- 响应数据结构
- 错误详细信息
- 连接测试日志

### 6. 常见问题FAQ

#### Q: 页面显示正常但无法生成计划？
A: 检查浏览器控制台是否有CORS错误，确保Dify服务允许跨域请求。

#### Q: API测试成功但生成计划失败？
A: 检查工作流是否正确配置，确保输出格式符合预期。

#### Q: 连接测试按钮显示成功但实际生成失败？
A: 可能是工作流配置问题，检查工作流的输入输出参数是否匹配。

#### Q: 如何查看更详细的错误信息？
A: 打开浏览器开发者工具(F12)，查看Console和Network标签页。

### 7. 获取帮助

如果以上步骤都无法解决问题，请：

1. 截图浏览器控制台的错误信息
2. 记录完整的错误提示
3. 检查Dify服务日志
4. 联系技术支持

### 8. 备用方案

如果暂时无法解决连接问题，可以：

1. **使用模拟数据**：临时启用前端模拟数据功能
2. **检查网络配置**：确认网络设置和代理配置
3. **尝试其他端口**：检查是否有端口冲突
4. **重启服务**：重启Dify服务和相关容器