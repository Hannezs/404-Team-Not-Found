// ==================== 配置区域 ====================
// ！！！重要：请将以下内容替换为你在 Dify 应用中获取的真实信息 ！！！
const DIFY_API_URL = 'http://localhost/v1/chat-messages'; // 在Dify工作流的"API集成"页面查找
const DIFY_API_KEY = 'app-0UGlu3FQudc5JdntYoJhSVGD'; // 在Dify的"设置"->"API密钥"中创建

// ==================== 配置结束 ====================

// 调试模式 - 设置为true时会在控制台输出详细信息
const DEBUG_MODE = true;

// 历史记录管理
const HISTORY_KEY = 'travel_plan_history';
const MAX_HISTORY_ITEMS = 10; // 最多保存10个历史记录

// 函数：保存旅行计划到历史记录
function saveToHistory(planData) {
    try {
        // 获取现有历史记录
        let history = getHistory();
        
        // 创建新的历史记录项
        const historyItem = {
            id: Date.now(), // 使用时间戳作为ID
            destination: planData.destination || document.getElementById('destination').value,
            days: planData.days || document.getElementById('days').value,
            travelDate: planData.travelDate || document.getElementById('travel-date').value,
            timestamp: new Date().toLocaleString('zh-CN'),
            planContent: planData.content || planData,
            budgetStyle: planData.budgetStyle || document.getElementById('budget-style').value,
            groupType: planData.groupType || getSelectedValues('group-type').join(', '),
            preferences: planData.preferences || getSelectedValues('preferences').join(', ')
        };
        
        // 将新记录添加到开头
        history.unshift(historyItem);
        
        // 限制历史记录数量
        if (history.length > MAX_HISTORY_ITEMS) {
            history = history.slice(0, MAX_HISTORY_ITEMS);
        }
        
        // 保存到localStorage
        localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
        
        if (DEBUG_MODE) {
            console.log('✅ 历史记录已保存:', historyItem);
        }
        
        // 更新历史记录显示
        displayHistory();
        
    } catch (error) {
        console.error('❌ 保存历史记录失败:', error);
    }
}

// 函数：获取历史记录
function getHistory() {
    try {
        const historyData = localStorage.getItem(HISTORY_KEY);
        return historyData ? JSON.parse(historyData) : [];
    } catch (error) {
        console.error('❌ 获取历史记录失败:', error);
        return [];
    }
}

// 函数：删除历史记录
function deleteHistoryItem(id) {
    try {
        let history = getHistory();
        history = history.filter(item => item.id !== id);
        localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
        
        if (DEBUG_MODE) {
            console.log('✅ 历史记录已删除, ID:', id);
        }
        
        // 更新历史记录显示
        displayHistory();
    } catch (error) {
        console.error('❌ 删除历史记录失败:', error);
    }
}

// 函数：清空所有历史记录
function clearAllHistory() {
    if (confirm('确定要清空所有历史记录吗？')) {
        localStorage.removeItem(HISTORY_KEY);
        displayHistory();
        
        if (DEBUG_MODE) {
            console.log('✅ 所有历史记录已清空');
        }
    }
}

// 函数：显示历史记录
function displayHistory() {
    const history = getHistory();
    const historyContainer = document.getElementById('history-container');

    if (!historyContainer) {
        console.warn('⚠️ 找不到历史记录容器');
        return;
    }

    // 更新历史记录计数显示
    const countElement = document.getElementById('history-count');
    if (countElement) {
        countElement.textContent = history.length;
        // 当没有历史记录时，可以选择隐藏计数或显示为灰色
        if (history.length === 0) {
            countElement.style.background = '#95a5a6'; // 灰色背景
            countElement.style.animation = 'none'; // 移除动画
        } else {
            countElement.style.background = '#ff6b6b'; // 红色背景
            countElement.style.animation = 'pulse 2s infinite'; // 添加动画
        }
        console.log('更新历史记录计数:', history.length);
    } else {
        console.warn('⚠️ 找不到历史记录计数元素');
    }

    if (history.length === 0) {
        historyContainer.innerHTML = `
            <div class="history-empty">
                <p>暂无历史记录</p>
                <p class="history-tip">开始规划您的第一个旅行计划吧！</p>
            </div>
        `;
        return;
    }

    const historyHtml = history.map(item => `
        <div class="history-item" data-id="${item.id}">
            <div class="history-header">
                <div class="history-info">
                    <h4>🌍 ${item.destination}</h4>
                    <p>📅 ${item.days}天 | ${item.timestamp}</p>
                    ${item.groupType ? `<p>👥 ${item.groupType}</p>` : ''}
                    ${item.budgetStyle ? `<p>💰 ${item.budgetStyle}</p>` : ''}
                </div>
                <div class="history-actions">
                    <button class="history-btn view-btn" onclick="viewHistoryItem(${item.id})" title="查看详情">
                        👁️ 查看
                    </button>
                    <button class="history-btn delete-btn" onclick="deleteHistoryItem(${item.id})" title="删除">
                        🗑️ 删除
                    </button>
                </div>
            </div>
        </div>
    `).join('');

    historyContainer.innerHTML = `
        <div class="history-list">
            ${historyHtml}
        </div>
        <div class="history-footer">
            <button class="clear-history-btn" onclick="clearAllHistory()">
                🗑️ 清空所有记录
            </button>
        </div>
    `;
}

// 切换历史记录面板显示状态
function toggleHistory() {
    const panel = document.getElementById('history-panel');
    if (!panel) return;
    
    if (panel.style.display === 'none' || !panel.style.display) {
        panel.style.display = 'block';
        displayHistory();
        console.log('显示历史记录面板');
    } else {
        panel.style.display = 'none';
        console.log('隐藏历史记录面板');
    }
}

// 页面加载完成后初始化历史记录计数
document.addEventListener('DOMContentLoaded', function() {
    const history = getHistory();
    const countElement = document.getElementById('history-count');
    if (countElement) {
        countElement.textContent = history.length;
        // 设置初始样式
        if (history.length === 0) {
            countElement.style.background = '#95a5a6'; // 灰色背景
            countElement.style.animation = 'none'; // 移除动画
        } else {
            countElement.style.background = '#ff6b6b'; // 红色背景
            countElement.style.animation = 'pulse 2s infinite'; // 添加动画
        }
    }
    console.log('历史记录初始化完成，当前记录数:', history.length);
    console.log('历史记录计数元素:', countElement);
});

// 函数：查看历史记录详情
function viewHistoryItem(id) {
    const history = getHistory();
    const item = history.find(h => h.id === id);
    
    if (!item) {
        alert('❌ 找不到该历史记录');
        return;
    }
    
    // 显示历史记录详情
    displayResults(item.planContent);
    
    // 滚动到结果区域
    setTimeout(() => {
        window.scrollTo({
            top: document.getElementById('result-section').offsetTop - 50,
            behavior: 'smooth'
        });
    }, 100);
    
    if (DEBUG_MODE) {
        console.log('✅ 查看历史记录:', item);
    }
}

// 获取选中的复选框值
function getSelectedValues(name) {
    const checkboxes = document.querySelectorAll(`input[name="${name}"]:checked`);
    return Array.from(checkboxes).map(cb => cb.value);
}

// 提取answer中的实际内容，移除<think>标签
function extractAnswerContent(answer) {
    if (!answer) return '';

    // 方法1：如果包含<think>标签，提取实际回答部分
    if (answer.includes('<think>') && answer.includes('</think>')) {
        // 提取</think>之后的内容
        const thinkEndIndex = answer.indexOf('</think>');
        if (thinkEndIndex !== -1) {
            const actualAnswer = answer.substring(thinkEndIndex + 8); // 8是</think>的长度
            return actualAnswer.trim();
        }
    }

    // 方法2：如果以\n\n开头（思考后的回答），提取后面的内容
    if (answer.includes('\n\n')) {
        const parts = answer.split('\n\n');
        if (parts.length > 1) {
            return parts.slice(1).join('\n\n').trim();
        }
    }

    // 方法3：直接返回原内容
    return answer;
}

// 主函数：生成旅行计划
async function generatePlan() {
    console.log('🚀 generatePlan 函数被调用');
    
    const destination = document.getElementById('destination').value;
    const days = document.getElementById('days').value;
    const budgetStyle = document.getElementById('budget-style').value;

    console.log('📍 表单数据:', { destination, days, budgetStyle });

    if (!destination) {
        alert('请输入目的地！');
        return;
    }

    const generateBtn = document.getElementById('generate-btn');
    const loadingElement = document.getElementById('loading');
    generateBtn.disabled = true;
    generateBtn.textContent = '规划中...';
    loadingElement.style.display = 'block';
    document.getElementById('result-section').style.display = 'none';

    try {
        // 获取所有表单数据
        const travelDate = document.getElementById('travel-date').value;
        const totalBudget = document.getElementById('total-budget').value;
        const groupTypes = getSelectedValues('group-type');
        const preferences = getSelectedValues('preferences');
        const mustVisit = document.getElementById('must-visit').value;
        const avoidItems = document.getElementById('avoid-items').value;

        // 构建请求数据 - 将所有参数放在query中
        const requestData = {
            inputs: {}, // 清空inputs，使用sys.query传递所有参数
            query: `请为以下需求生成详细的旅行计划：

目的地：${destination}
旅行天数：${days}天
预算风格：${budgetStyle}
出发日期：${travelDate || '未指定'}
总预算：${totalBudget ? totalBudget + '元' : '未指定'}
人群组成：${groupTypes.join('、') || '未指定'}
特殊偏好：${preferences.join('、') || '无'}
必去景点：${mustVisit || '无'}
避开项目：${avoidItems || '无'}

请生成包含以下内容的详细旅行计划：
1. 📅 每日详细行程安排（分上午、下午、晚上）
2. 🏞️ 景点推荐（请为每个主要景点生成图片）
3. 🏨 酒店推荐（按预算分级）
4. 🍽️ 美食推荐（当地特色）
5. 💡 实用旅行信息（天气、交通、注意事项）`,
            response_mode: 'blocking',
            user: 'user-' + Date.now()
        };

        if (DEBUG_MODE) {
            console.log('🚀 发送请求数据:', requestData);
            console.log('📡 API配置:', { url: DIFY_API_URL, key: DIFY_API_KEY.substring(0, 10) + '...' });
        }

        const response = await fetch(DIFY_API_URL, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${DIFY_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error('❌ API响应错误:', errorText);
            throw new Error(`网络请求失败: ${response.status} ${response.statusText}\n${errorText}`);
        }

        const data = await response.json();
        if (DEBUG_MODE) {
            console.log('✅ API响应数据:', data);
        }

        // 处理API返回的数据
        let resultText = '';
        if (data && data.answer) {
            // 提取answer中的实际内容，移除<think>标签
            resultText = extractAnswerContent(data.answer);
            if (DEBUG_MODE) {
                console.log('🔍 提取后的内容:', resultText);
            }
        } else if (data && data.data && data.data.outputs && data.data.outputs.text) {
            resultText = data.data.outputs.text;
        } else if (data && data.message) {
            resultText = data.message;
        } else {
            console.error('📊 返回数据结构:', data);
            resultText = JSON.stringify(data, null, 2);
        }

        displayResults(resultText);

        // 保存到历史记录
        const planData = {
            destination: destination,
            days: days,
            budgetStyle: budgetStyle,
            travelDate: travelDate,
            groupType: groupTypes.join(', '),
            preferences: preferences.join(', '),
            content: resultText
        };
        saveToHistory(planData);

    } catch (error) {
        console.error('❌ 错误详情:', error);

        let errorMessage = '生成计划失败：' + error.message;

        if (error.message.includes('Failed to fetch')) {
            errorMessage += '\n\n🔧 可能的解决方案：\n';
            errorMessage += '1. 检查Dify服务是否正在运行\n';
            errorMessage += '2. 确认API地址是否正确\n';
            errorMessage += '3. 检查防火墙设置\n';
            errorMessage += '4. 尝试刷新页面或重启Dify服务';
        } else {
            errorMessage += '\n\n请检查：\n';
            errorMessage += '1. API配置是否正确\n';
            errorMessage += '2. 网络连接是否正常\n';
            errorMessage += '3. 工作流是否正常运行';
        }

        alert(errorMessage);
    } finally {
        generateBtn.disabled = false;
        generateBtn.textContent = '生成专属旅行计划';
        loadingElement.style.display = 'none';
        console.log('🔄 generatePlan 函数执行完成');
    }
}

// 函数：重新生成计划
function regeneratePlan() {
    generatePlan();
}

// 函数：导出计划
function exportPlan() {
    const resultContent = document.getElementById('result-section').innerText;
    const blob = new Blob([resultContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = '我的旅行计划.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// 函数：显示结果
function displayResults(fullText) {
    if (!fullText) {
        document.getElementById('itinerary-content').innerHTML = '<div class="content-card"><p>未获取到有效内容，请检查API配置或稍后重试。</p></div>';
        return;
    }

    try {
        // 尝试解析JSON格式的结果
        let parsedData;
        try {
            parsedData = JSON.parse(fullText);
        } catch (e) {
            // 如果不是JSON，按纯文本处理
            console.log('按纯文本格式处理结果');
            displayTextResults(fullText);
            return;
        }

        // 如果成功解析为JSON，按结构化数据展示
        if (parsedData) {
            displayStructuredResults(parsedData);
        }

    } catch (error) {
        console.error('显示结果时出错:', error);
        displayTextResults(fullText);
    }

    // 显示结果区域
    document.getElementById('result-section').style.display = 'block';
    window.scrollTo({ top: document.getElementById('result-section').offsetTop - 20, behavior: 'smooth' });
}

// 函数：显示结构化结果
function displayStructuredResults(data) {
    // 行程安排
    if (data.itinerary) {
        document.getElementById('itinerary-content').innerHTML = formatItinerary(data.itinerary);
    }

    // 景点推荐
    if (data.attractions) {
        document.getElementById('attractions-content').innerHTML = formatAttractions(data.attractions);
    }

    // 酒店推荐
    if (data.hotels) {
        document.getElementById('hotels-content').innerHTML = formatHotels(data.hotels);
    }

    // 美食推荐
    if (data.food) {
        document.getElementById('food-content').innerHTML = formatFood(data.food);
    }

    // 实用信息
    if (data.practical) {
        document.getElementById('practical-content').innerHTML = formatPractical(data.practical);
    }
}

// 函数：解析markdown文本为HTML
function parseMarkdownToHtml(markdownText) {
    if (!markdownText) return '';
    
    // 配置marked选项
    marked.setOptions({
        breaks: true,  // 支持换行
        gfm: true,     // GitHub风格的markdown
        headerIds: false,
        mangle: false,
        sanitize: false // 允许HTML标签通过
    });
    
    // 解析markdown为HTML
    return marked.parse(markdownText);
}

// 函数：显示文本结果
function displayTextResults(fullText) {
    console.log('🔍 displayTextResults被调用，内容长度:', fullText?.length);

    if (!fullText || fullText.trim() === '') {
        const errorHtml = '<div class="content-card"><p>❌ 未获取到有效内容，请检查API配置或稍后重试。</p></div>';
        document.getElementById('itinerary-content').innerHTML = errorHtml;
        document.getElementById('attractions-content').innerHTML = errorHtml;
        document.getElementById('hotels-content').innerHTML = errorHtml;
        document.getElementById('food-content').innerHTML = errorHtml;
        document.getElementById('practical-content').innerHTML = errorHtml;
        return;
    }

    // 尝试智能解析markdown内容到不同标签页
    try {
        // 解析markdown为HTML
        const htmlContent = parseMarkdownToHtml(fullText);
        
        // 尝试提取不同部分的内容
        const itineraryMatch = fullText.match(/###\s*\**\s*[📅]\s*.*?每日详细行程安排\s*\**[\s\S]*?(?=###|$)/i);
        const attractionsMatch = fullText.match(/###\s*\**\s*[🏞️]\s*.*?景点推荐\s*\**[\s\S]*?(?=###|$)/i);
        const hotelsMatch = fullText.match(/###\s*\**\s*[🏨]\s*.*?酒店推荐\s*\**[\s\S]*?(?=###|$)/i);
        const foodMatch = fullText.match(/###\s*\**\s*[🍽️]\s*.*?美食推荐\s*\**[\s\S]*?(?=###|$)/i);
        const practicalMatch = fullText.match(/###\s*\**\s*[💡]\s*.*?实用旅行信息\s*\**[\s\S]*?(?=###|$)/i);

        // 为每个标签页设置对应内容
        document.getElementById('itinerary-content').innerHTML = itineraryMatch ? 
            `<div class="content-card">${parseMarkdownToHtml(itineraryMatch[0])}</div>` : 
            `<div class="content-card">${htmlContent}</div>`;
            
        document.getElementById('attractions-content').innerHTML = attractionsMatch ? 
            `<div class="content-card">${parseMarkdownToHtml(attractionsMatch[0])}</div>` : 
            `<div class="content-card">${htmlContent}</div>`;
            
        document.getElementById('hotels-content').innerHTML = hotelsMatch ? 
            `<div class="content-card">${parseMarkdownToHtml(hotelsMatch[0])}</div>` : 
            `<div class="content-card">${htmlContent}</div>`;
            
        document.getElementById('food-content').innerHTML = foodMatch ? 
            `<div class="content-card">${parseMarkdownToHtml(foodMatch[0])}</div>` : 
            `<div class="content-card">${htmlContent}</div>`;
            
        document.getElementById('practical-content').innerHTML = practicalMatch ? 
            `<div class="content-card">${parseMarkdownToHtml(practicalMatch[0])}</div>` : 
            `<div class="content-card">${htmlContent}</div>`;

    } catch (error) {
        console.error('解析内容时出错:', error);
        // 如果解析失败，显示原始内容但使用更好的样式
        const fallbackContent = `
            <div class="content-card">
                <h4>🎉 您的专属旅行计划已生成！</h4>
                <div class="travel-plan-content">
                    ${parseMarkdownToHtml(fullText)}
                </div>
            </div>
        `;
        
        // 在所有标签页显示内容
        document.getElementById('itinerary-content').innerHTML = fallbackContent;
        document.getElementById('attractions-content').innerHTML = fallbackContent;
        document.getElementById('hotels-content').innerHTML = fallbackContent;
        document.getElementById('food-content').innerHTML = fallbackContent;
        document.getElementById('practical-content').innerHTML = fallbackContent;
    }

    console.log('✅ 结果区域已显示，内容长度:', fullText?.length);
}

// 函数：显示结果（修复重复定义问题）
function displayResults(fullText) {
    console.log('🔍 displayResults被调用，内容长度:', fullText?.substring(0, 100) + '...');

    if (!fullText || fullText.trim() === '') {
        const errorHtml = '<div class="content-card"><p>❌ 未获取到有效内容，请检查API配置或稍后重试。</p></div>';
        document.getElementById('itinerary-content').innerHTML = errorHtml;
        document.getElementById('attractions-content').innerHTML = errorHtml;
        document.getElementById('hotels-content').innerHTML = errorHtml;
        document.getElementById('food-content').innerHTML = errorHtml;
        document.getElementById('practical-content').innerHTML = errorHtml;
    } else {
        // 调用文本结果显示函数
        displayTextResults(fullText);
    }

    // 强制显示结果区域
    const resultSection = document.getElementById('result-section');
    resultSection.style.display = 'block';

    // 滚动到结果区域
    setTimeout(() => {
        window.scrollTo({
            top: resultSection.offsetTop - 50,
            behavior: 'smooth'
        });
    }, 100);
}
// 函数：提取文本段落
function extractSection(text, keywords) {
    for (const keyword of keywords) {
        const regex = new RegExp(`${keyword}[\\s\\S]*?(?=#|###|$)`, 'i');
        const match = text.match(regex);
        if (match) {
            return `<div class="content-card"><h4>${keyword}</h4><pre>${match[0].replace(new RegExp(keyword, 'i'), '').trim()}</pre></div>`;
        }
    }
    return '';
}

// 函数：格式化行程
function formatItinerary(itinerary) {
    if (Array.isArray(itinerary)) {
        return itinerary.map(day => `
            <div class="content-card">
                <h4>📅 ${day.day || '第' + (itinerary.indexOf(day) + 1) + '天'}</h4>
                <div class="day-schedule">
                    ${day.morning ? `<p><strong>上午：</strong>${day.morning}</p>` : ''}
                    ${day.afternoon ? `<p><strong>下午：</strong>${day.afternoon}</p>` : ''}
                    ${day.evening ? `<p><strong>晚上：</strong>${day.evening}</p>` : ''}
                    ${day.notes ? `<p><strong>备注：</strong>${day.notes}</p>` : ''}
                </div>
            </div>
        `).join('');
    }
    return `<div class="content-card"><pre>${JSON.stringify(itinerary, null, 2)}</pre></div>`;
}

// 函数：格式化景点
function formatAttractions(attractions) {
    if (Array.isArray(attractions)) {
        return attractions.map(attraction => `
            <div class="attraction-card">
                <h4>🏞️ ${attraction.name || '景点名称'}</h4>
                <div class="attraction-meta">
                    ${attraction.address ? `<span>📍 ${attraction.address}</span>` : ''}
                    ${attraction.ticket_price ? `<span>🎫 ${attraction.ticket_price}</span>` : ''}
                    ${attraction.open_time ? `<span>⏰ ${attraction.open_time}</span>` : ''}
                    ${attraction.duration ? `<span>⏱️ ${attraction.duration}</span>` : ''}
                </div>
                ${attraction.description ? `<p>${attraction.description}</p>` : ''}
                ${attraction.highlights ? `<p><strong>特色亮点：</strong>${attraction.highlights}</p>` : ''}
                ${attraction.image ? `<img src="${attraction.image}" alt="${attraction.name}">` : ''}
            </div>
        `).join('');
    }
    return `<div class="content-card"><pre>${JSON.stringify(attractions, null, 2)}</pre></div>`;
}

// 函数：格式化酒店
function formatHotels(hotels) {
    if (Array.isArray(hotels)) {
        return hotels.map(hotel => `
            <div class="attraction-card">
                <h4>🏨 ${hotel.name || '酒店名称'}</h4>
                <div class="attraction-meta">
                    ${hotel.rating ? `<span>⭐ ${hotel.rating}分</span>` : ''}
                    ${hotel.price_range ? `<span>💰 ${hotel.price_range}</span>` : ''}
                    ${hotel.location ? `<span>📍 ${hotel.location}</span>` : ''}
                </div>
                ${hotel.description ? `<p>${hotel.description}</p>` : ''}
                ${hotel.facilities ? `<p><strong>设施服务：</strong>${hotel.facilities}</p>` : ''}
                ${hotel.suitable_for ? `<p><strong>适合人群：</strong>${hotel.suitable_for}</p>` : ''}
            </div>
        `).join('');
    }
    return `<div class="content-card"><pre>${JSON.stringify(hotels, null, 2)}</pre></div>`;
}

// 函数：格式化美食
function formatFood(food) {
    if (Array.isArray(food)) {
        return food.map(restaurant => `
            <div class="attraction-card">
                <h4>🍽️ ${restaurant.name || '餐厅名称'}</h4>
                <div class="attraction-meta">
                    ${restaurant.cuisine ? `<span>🍜 ${restaurant.cuisine}</span>` : ''}
                    ${restaurant.price_range ? `<span>💰 ${restaurant.price_range}</span>` : ''}
                    ${restaurant.rating ? `<span>⭐ ${restaurant.rating}分</span>` : ''}
                    ${restaurant.address ? `<span>📍 ${restaurant.address}</span>` : ''}
                </div>
                ${restaurant.description ? `<p>${restaurant.description}</p>` : ''}
                ${restaurant.specialty ? `<p><strong>招牌菜：</strong>${restaurant.specialty}</p>` : ''}
                ${restaurant.opening_hours ? `<p><strong>营业时间：</strong>${restaurant.opening_hours}</p>` : ''}
            </div>
        `).join('');
    }
    return `<div class="content-card"><pre>${JSON.stringify(food, null, 2)}</pre></div>`;
}

// 函数：格式化实用信息
function formatPractical(practical) {
    if (typeof practical === 'object') {
        let html = '';
        for (const [key, value] of Object.entries(practical)) {
            html += `<div class="content-card"><h4>${key}</h4><p>${value}</p></div>`;
        }
        return html;
    }
    return `<div class="content-card"><pre>${JSON.stringify(practical, null, 2)}</pre></div>`;
}

// 函数：切换标签页
function openTab(tabName) {
    console.log('🔄 切换标签页:', tabName);
    
    // 隐藏所有标签内容
    const tabContents = document.getElementsByClassName('tab-content');
    for (let i = 0; i < tabContents.length; i++) {
        tabContents[i].classList.remove('active');
    }

    // 取消所有标签按钮的激活状态
    const tabButtons = document.getElementsByClassName('tab-button');
    for (let i = 0; i < tabButtons.length; i++) {
        tabButtons[i].classList.remove('active');
    }

    // 显示当前标签内容
    const targetTab = document.getElementById(tabName);
    if (targetTab) {
        targetTab.classList.add('active');
        console.log('✅ 显示标签内容:', tabName);
    } else {
        console.error('❌ 找不到标签:', tabName);
    }
    
    // 激活当前点击的按钮
    const clickedButton = event.currentTarget;
    if (clickedButton) {
        clickedButton.classList.add('active');
        console.log('✅ 激活按钮:', clickedButton.textContent);
    } else {
        console.log('⚠️ 无法获取点击的按钮');
    }
}

// 函数：分享计划
function sharePlan() {
    const resultContent = document.getElementById('result-section').innerText;

    if (navigator.share) {
        // 使用Web Share API
        navigator.share({
            title: '我的旅行计划',
            text: resultContent.substring(0, 500) + '...', // 限制长度
            url: window.location.href
        }).catch(err => {
            console.log('分享取消:', err);
        });
    } else {
        // 复制到剪贴板
        navigator.clipboard.writeText(resultContent).then(() => {
            alert('旅行计划已复制到剪贴板！');
        }).catch(err => {
            console.error('复制失败:', err);
            alert('复制失败，请手动复制内容。');
        });
    }
}

// 函数：显示智能提示
function showSmartTips() {
    const tips = [
        '💡 小贴士：选择合适的人群类型可以获得更精准的推荐',
        '🌟 建议：添加特殊偏好可以让AI更好地理解您的需求',
        '💰 提示：设置总预算范围有助于获得更符合预算的建议',
        '📅 提醒：提前规划行程可以获得更好的酒店和机票价格',
        '🎯 技巧：在必去景点中输入多个地点，用逗号分隔'
    ];

    const randomTip = tips[Math.floor(Math.random() * tips.length)];

    // 创建提示元素
    const tipElement = document.createElement('div');
    tipElement.className = 'smart-tip';
    tipElement.innerHTML = `
        <div class="tip-content">
            <span class="tip-icon">💡</span>
            <span class="tip-text">${randomTip}</span>
            <button class="tip-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;

    // 添加到页面
    document.body.appendChild(tipElement);

    // 3秒后自动消失
    setTimeout(() => {
        if (tipElement.parentElement) {
            tipElement.remove();
        }
    }, 5000);
}

// 函数：测试API连接
async function testAPIConnection() {
    if (DEBUG_MODE) {
        console.log('🔍 开始测试API连接...');
    }

    try {
        const response = await fetch(DIFY_API_URL, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${DIFY_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                inputs: {},
                query: "测试连接：请回复'连接成功'",
                response_mode: 'blocking',
                user: 'test-user'
            })
        });

        if (response.ok) {
            const data = await response.json();
            if (DEBUG_MODE) {
                console.log('✅ API连接测试成功:', data);
            }
            return { success: true, data: data };
        } else {
            const errorText = await response.text();
            if (DEBUG_MODE) {
                console.error('❌ API连接测试失败:', response.status, errorText);
            }
            return { success: false, error: `HTTP ${response.status}: ${errorText}` };
        }
    } catch (error) {
        if (DEBUG_MODE) {
            console.error('❌ API连接测试失败:', error);
        }
        return { success: false, error: error.message };
    }
}

// 函数：用户界面测试连接
async function testConnection() {
    const testBtn = document.querySelector('.test-btn');
    const originalText = testBtn.innerHTML;

    testBtn.innerHTML = '<span class="btn-icon">⏳</span> 测试中...';
    testBtn.disabled = true;

    try {
        const result = await testAPIConnection();

        if (result.success) {
            alert('✅ API连接测试成功！\n\n' +
                '📍 API地址: ' + DIFY_API_URL + '\n' +
                '🔑 API密钥: ' + DIFY_API_KEY.substring(0, 10) + '...\n' +
                '📊 响应状态: 正常');

            if (DEBUG_MODE && result.data) {
                console.log('📋 测试响应数据:', result.data);
            }
        } else {
            alert('❌ API连接测试失败！\n\n' +
                '错误信息: ' + result.error + '\n\n' +
                '🔧 解决方案:\n' +
                '1. 检查Dify服务是否正在运行\n' +
                '2. 确认API地址是否正确\n' +
                '3. 验证API密钥是否有效\n' +
                '4. 检查网络连接和防火墙设置');
        }
    } catch (error) {
        console.error('测试连接时出错:', error);
        alert('❌ 测试连接时发生错误:\n' + error.message);
    } finally {
        testBtn.innerHTML = originalText;
        testBtn.disabled = false;
    }
}